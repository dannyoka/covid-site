from django.shortcuts import render
from django.views.generic import TemplateView

# Create your views here.
class HomeView(TemplateView):
	"""docstring for HomeView"""
	template_name = 'basicApp/home.html'

class AboutView(TemplateView):
	"""docstring for AboutView"""
	template_name = 'basicApp/about.html'

class RequestMoreInfoView(TemplateView):
	"""docstring for AboutView"""
	template_name = 'basicApp/request_more_info.html'